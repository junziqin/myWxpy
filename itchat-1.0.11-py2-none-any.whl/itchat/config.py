import os, platform

DIR = os.getcwd()
BASE_URL = 'https://login.weixin.qq.com'
OS = platform.system() #Windows, Linux, Darwin

WELCOME_WORDS = 'Hello World!'
